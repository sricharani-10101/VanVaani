"""
PS-7 FRA Monitoring — Member 3: AI Anomaly Detection Engine
Consumes fra_data.json -> produces anomalies.json

Usage:
    python anomaly_engine.py                  # uses fra_data.json if present, else generates mock data
    python anomaly_engine.py --mock 30         # force-generate 30 mock rows and run on them
    python anomaly_engine.py --input path.json # run on a specific file

No UI. No browser needed. Pure CLI.
"""

import json
import random
import argparse
import os
from datetime import datetime, timedelta

# ---------------------------------------------------------------------------
# 0. CONFIG — agree on these once, don't change mid-build
# ---------------------------------------------------------------------------

RULE_WEIGHTS = {
    "DELAYED_CLAIM": 30,
    "LAND_RECORD_MISMATCH": 40,
    "DATE_INCONSISTENCY": 35,
    "UNUSUAL_REJECTION_RATE": 25,
}

DELAYED_CLAIM_DAYS = 180
LAND_MISMATCH_THRESHOLD = 0.20  # 20%
REJECTION_RATE_STD_MULTIPLIER = 1.5  # how many std-devs above district baseline counts as unusual

SEVERITY_BANDS = [
    (70, 100, "HIGH"),
    (40, 69, "MEDIUM"),
    (0, 39, "LOW"),
]

# Real district set for the demo (Madhya Pradesh), grouped into 4 regional
# clusters so the accompanying map layer stays visually connected instead of
# scattered. Group membership isn't used by the anomaly rules themselves —
# it's here so this file stays the single source of truth for "which
# districts exist" across the whole team.
DISTRICT_GROUPS = {
    "Central & Eastern Forest Belt": ["Mandla", "Dindori", "Balaghat", "Seoni", "Chhindwara"],
    "Shahdol Region": ["Shahdol", "Umaria", "Anuppur"],
    "Western Tribal Belt": ["Alirajpur", "Jhabua", "Barwani"],
    "Southern / Forest-Connected": ["Betul", "Sidhi", "Singrauli", "Panna"],
}

STATES_DISTRICTS = {
    "Madhya Pradesh": [d for districts in DISTRICT_GROUPS.values() for d in districts]
}

# ---------------------------------------------------------------------------
# 1. MOCK DATA GENERATOR (use only if Member 2's real file isn't ready yet)
# ---------------------------------------------------------------------------

def generate_mock_data(n=25, seed=42):
    random.seed(seed)
    rows = []
    today = datetime(2026, 9, 4)

    for i in range(1, n + 1):
        state = random.choice(list(STATES_DISTRICTS.keys()))
        district = random.choice(STATES_DISTRICTS[state])

        claim_date = today - timedelta(days=random.randint(10, 400))
        # ~30% of claims still pending, rest approved/rejected
        status = random.choices(
            ["PENDING", "APPROVED", "REJECTED"], weights=[0.3, 0.55, 0.15]
        )[0]

        if status == "PENDING":
            approval_date = None
        else:
            # occasionally inject a bad row: approval before claim (DATE_INCONSISTENCY)
            if random.random() < 0.08:
                approval_date = claim_date - timedelta(days=random.randint(1, 20))
            else:
                approval_date = claim_date + timedelta(days=random.randint(5, 200))

        land_area = round(random.uniform(1.0, 10.0), 2)
        # occasionally inject a land record mismatch
        if random.random() < 0.15:
            land_record_area = round(land_area * random.uniform(0.4, 0.7), 2)
        else:
            land_record_area = round(land_area * random.uniform(0.92, 1.08), 2)

        rows.append({
            "claim_id": f"FRA{1000 + i}",
            "state": state,
            "district": district,
            "claim_date": claim_date.strftime("%Y-%m-%d"),
            "approval_date": approval_date.strftime("%Y-%m-%d") if approval_date else None,
            "status": status,
            "land_area": land_area,
            "land_record_area": land_record_area,
        })

    return rows


# ---------------------------------------------------------------------------
# 2. VALIDATION — never crash on bad rows, just skip + log
# ---------------------------------------------------------------------------

REQUIRED_FIELDS = ["claim_id", "state", "district", "claim_date", "status",
                   "land_area", "land_record_area"]

def validate_row(row):
    for field in REQUIRED_FIELDS:
        if field not in row or row[field] is None:
            return False, f"missing field: {field}"
    try:
        datetime.strptime(row["claim_date"], "%Y-%m-%d")
        if row.get("approval_date"):
            datetime.strptime(row["approval_date"], "%Y-%m-%d")
    except (ValueError, TypeError):
        return False, "bad date format"
    return True, None


# ---------------------------------------------------------------------------
# 3. RULE ENGINE — rules decide IF something is anomalous
# ---------------------------------------------------------------------------

def check_delayed_claim(row, today):
    if row["status"] != "PENDING":
        return None
    claim_date = datetime.strptime(row["claim_date"], "%Y-%m-%d")
    days_pending = (today - claim_date).days
    if days_pending > DELAYED_CLAIM_DAYS:
        return {
            "type": "DELAYED_CLAIM",
            "detail": f"Claim has been pending for {days_pending} days (threshold: {DELAYED_CLAIM_DAYS})."
        }
    return None


def check_land_record_mismatch(row):
    land_area = row["land_area"]
    record_area = row["land_record_area"]
    if record_area == 0:
        return None
    diff_pct = abs(land_area - record_area) / record_area
    if diff_pct > LAND_MISMATCH_THRESHOLD:
        return {
            "type": "LAND_RECORD_MISMATCH",
            "detail": f"Claimed area {land_area} ha vs recorded {record_area} ha "
                      f"({diff_pct*100:.1f}% difference)."
        }
    return None


def check_date_inconsistency(row):
    if not row.get("approval_date"):
        return None
    claim_date = datetime.strptime(row["claim_date"], "%Y-%m-%d")
    approval_date = datetime.strptime(row["approval_date"], "%Y-%m-%d")
    if approval_date < claim_date:
        return {
            "type": "DATE_INCONSISTENCY",
            "detail": f"Approval date ({row['approval_date']}) is before claim date ({row['claim_date']})."
        }
    return None


def check_unusual_rejection_rate(all_rows):
    """District-level check: flags every REJECTED claim in a district whose
    rejection rate is far above the state average."""
    from collections import defaultdict

    state_totals = defaultdict(lambda: {"total": 0, "rejected": 0})
    district_totals = defaultdict(lambda: {"total": 0, "rejected": 0})

    for row in all_rows:
        key_state = row["state"]
        key_district = (row["state"], row["district"])
        state_totals[key_state]["total"] += 1
        district_totals[key_district]["total"] += 1
        if row["status"] == "REJECTED":
            state_totals[key_state]["rejected"] += 1
            district_totals[key_district]["rejected"] += 1

    flagged_districts = set()
    for (state, district), stats in district_totals.items():
        if stats["total"] < 3:
            continue  # not enough data to judge
        district_rate = stats["rejected"] / stats["total"]
        state_rate = (state_totals[state]["rejected"] / state_totals[state]["total"]
                      if state_totals[state]["total"] else 0)
        if district_rate > state_rate * REJECTION_RATE_STD_MULTIPLIER and district_rate > 0.2:
            flagged_districts.add((state, district))

    return flagged_districts


def run_rules(rows, today):
    """Returns a dict: claim_id -> list of triggered rule hits."""
    hits_by_claim = {}

    flagged_districts = check_unusual_rejection_rate(rows)

    for row in rows:
        hits = []
        for check in (check_delayed_claim, check_land_record_mismatch, check_date_inconsistency):
            result = check(row, today) if check is check_delayed_claim else check(row)
            if result:
                hits.append(result)

        if row["status"] == "REJECTED" and (row["state"], row["district"]) in flagged_districts:
            hits.append({
                "type": "UNUSUAL_REJECTION_RATE",
                "detail": f"{row['district']} district's rejection rate is significantly "
                          f"above the {row['state']} state average."
            })

        if hits:
            hits_by_claim[row["claim_id"]] = hits

    return hits_by_claim


# ---------------------------------------------------------------------------
# 4. SCORING
# ---------------------------------------------------------------------------

def compute_score_and_severity(hits):
    score = min(100, sum(RULE_WEIGHTS.get(h["type"], 10) for h in hits))
    for low, high, label in SEVERITY_BANDS:
        if low <= score <= high:
            return score, label
    return score, "LOW"


# ---------------------------------------------------------------------------
# 5. EXPLANATION LAYER — LLM explains AFTER the rule engine has decided.
#    Falls back to a template if no API key / network / rate limit — this
#    keeps your demo alive even if the free LLM tier hiccups live.
# ---------------------------------------------------------------------------

TEMPLATE_EXPLANATIONS = {
    "DELAYED_CLAIM": "This claim has been pending significantly longer than the standard processing window. It may need administrative follow-up.",
    "LAND_RECORD_MISMATCH": "The claimed land area differs substantially from the officially recorded area. This claim may require manual verification.",
    "DATE_INCONSISTENCY": "The recorded approval date precedes the claim date, which is not possible under normal processing. This suggests a data entry error worth checking.",
    "UNUSUAL_REJECTION_RATE": "This claim's district shows a rejection rate well above the state average, which may indicate inconsistent review practices worth auditing.",
}

TEMPLATE_RECOMMENDATIONS = {
    "DELAYED_CLAIM": "Escalate for administrative review.",
    "LAND_RECORD_MISMATCH": "Manual verification recommended.",
    "DATE_INCONSISTENCY": "Data entry correction recommended.",
    "UNUSUAL_REJECTION_RATE": "District-level audit recommended.",
}


def generate_explanation(claim_id, hits, use_llm=False):
    """
    Set use_llm=True and fill in call_llm() below to use a real free LLM API
    (e.g. Groq, Gemini free tier, HuggingFace inference). Defaults to
    template mode, which is fast, free, and never fails during a demo.
    """
    primary_type = hits[0]["type"]

    if use_llm:
        try:
            return call_llm(claim_id, hits)
        except Exception:
            pass  # fall through to template

    explanation = TEMPLATE_EXPLANATIONS.get(primary_type, "This claim was flagged by the rule engine for review.")
    recommendation = TEMPLATE_RECOMMENDATIONS.get(primary_type, "Manual review recommended.")
    return explanation, recommendation


def call_llm(claim_id, hits):
    """
    Plug in a real free LLM call here if you have time, e.g.:

    import requests
    prompt = f"Explain in one plain-English sentence why claim {claim_id} was " \\
             f"flagged for: {[h['type'] for h in hits]}. Details: {[h['detail'] for h in hits]}. " \\
             f"Then give a one-line recommendation."
    resp = requests.post("<free LLM endpoint>", json={...}, timeout=5)
    text = resp.json()[...]
    # split text into explanation / recommendation and return both
    raise NotImplementedError("Wire up your free LLM API here")
    """
    raise NotImplementedError


# ---------------------------------------------------------------------------
# 6. MAIN PIPELINE
# ---------------------------------------------------------------------------

def build_anomalies(rows, use_llm=False):
    today = datetime(2026, 9, 4)
    valid_rows = []
    for row in rows:
        ok, reason = validate_row(row)
        if ok:
            valid_rows.append(row)
        else:
            print(f"[skip] {row.get('claim_id', '?')}: {reason}")

    hits_by_claim = run_rules(valid_rows, today)
    row_lookup = {r["claim_id"]: r for r in valid_rows}

    anomalies = []
    for claim_id, hits in hits_by_claim.items():
        row = row_lookup[claim_id]
        score, severity = compute_score_and_severity(hits)
        explanation, recommendation = generate_explanation(claim_id, hits, use_llm=use_llm)
        # primary type = whichever rule hit contributed the most weight
        primary_hit = max(hits, key=lambda h: RULE_WEIGHTS.get(h["type"], 0))

        anomalies.append({
            "claim_id": claim_id,
            "state": row["state"],
            "district": row["district"],
            "severity": severity,
            "risk_score": score,
            "type": primary_hit["type"],
            "explanation": explanation,
            "recommendation": recommendation,
        })

    anomalies.sort(key=lambda a: a["risk_score"], reverse=True)
    return anomalies


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="fra_data.json", help="path to claim data")
    parser.add_argument("--output", default="anomalies.json", help="path to write output")
    parser.add_argument("--mock", type=int, default=0, help="generate N mock rows instead of reading --input")
    parser.add_argument("--use-llm", action="store_true", help="attempt real LLM call for explanations")
    args = parser.parse_args()

    if args.mock:
        rows = generate_mock_data(n=args.mock)
        mock_path = "fra_data.json"
        with open(mock_path, "w") as f:
            json.dump(rows, f, indent=2)
        print(f"Generated {len(rows)} mock rows -> {mock_path}")
    elif os.path.exists(args.input):
        with open(args.input) as f:
            rows = json.load(f)
        print(f"Loaded {len(rows)} rows from {args.input}")
    else:
        print(f"No {args.input} found — generating 25 mock rows instead.")
        rows = generate_mock_data(n=25)
        with open("fra_data.json", "w") as f:
            json.dump(rows, f, indent=2)

    anomalies = build_anomalies(rows, use_llm=args.use_llm)

    with open(args.output, "w") as f:
        json.dump(anomalies, f, indent=2)

    print(f"\n{len(anomalies)} anomalies flagged out of {len(rows)} claims -> {args.output}")
    for a in anomalies[:5]:
        print(f"  [{a['severity']:6}] {a['claim_id']} — {a['type']} (score {a['risk_score']})")


if __name__ == "__main__":
    main()
