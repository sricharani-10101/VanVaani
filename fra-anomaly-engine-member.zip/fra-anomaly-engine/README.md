# FRA Anomaly Detection Engine

**PS-7 — AI-powered Decision Support System for Forest Rights Act (FRA) Monitoring**
Member 3's module: turns raw FRA claim data into a scored, explained anomaly feed.

This module has **no UI**. It is a pure data pipeline: `fra_data.json` in →
`anomalies.json` out. It's designed to run standalone from the command line
and to be swapped in behind the team's dashboard (Member 4) with a one-line
file-path change.

## Pipeline

```
fra_data.json (real or self-mocked)
        │
        ▼
  data validation  (bad rows are skipped + logged, never crash the run)
        │
        ▼
  rule / statistical checks
        │
        ▼
  anomaly flags + risk score + severity
        │
        ▼
  explanation layer (template-based by default, pluggable LLM)
        │
        ▼
  anomalies.json
```

## Rules implemented

| Flag | Rule |
|---|---|
| `DELAYED_CLAIM` | claim pending > 180 days |
| `LAND_RECORD_MISMATCH` | `abs(land_area − land_record_area) / land_record_area` exceeds 20% |
| `DATE_INCONSISTENCY` | `approval_date < claim_date` |
| `UNUSUAL_REJECTION_RATE` | a district's rejection rate is far above its own state average |

Rules decide *whether* a claim is anomalous. The explanation layer only
describes *why*, after the fact — it never makes the anomaly call itself.

## Scoring

`risk_score` is a weighted sum of triggered rule hits, capped at 100:

- `LOW` 0–39
- `MEDIUM` 40–69
- `HIGH` 70–100

Weights are defined once at the top of `anomaly_engine.py` in `RULE_WEIGHTS`
and should not change mid-build once agreed with the rest of the team.

## District data

The mock generator uses the real 15-district set for this build, grouped
into 4 regional clusters (kept here so it stays the one source of truth
for "which districts exist" across map/dashboard/engine):

- **Central & Eastern Forest Belt:** Mandla, Dindori, Balaghat, Seoni, Chhindwara
- **Shahdol Region:** Shahdol, Umaria, Anuppur
- **Western Tribal Belt:** Alirajpur, Jhabua, Barwani
- **Southern / Forest-Connected:** Betul, Sidhi, Singrauli, Panna

## Output contract — `anomalies.json`

```json
[
  {
    "claim_id": "FRA1023",
    "state": "Madhya Pradesh",
    "district": "Seoni",
    "severity": "HIGH",
    "risk_score": 87,
    "type": "LAND_RECORD_MISMATCH",
    "explanation": "The claimed land area is substantially higher than the recorded land area. This claim may require manual verification.",
    "recommendation": "Manual verification recommended."
  }
]
```

This shape is fixed by team agreement — do not rename fields without telling
Member 4, whose dashboard reads this file directly.

## Usage

```bash
# Generate mock data and run the full pipeline
python anomaly_engine.py --mock 30

# Run against a real data file once it's available
python anomaly_engine.py --input fra_data.json --output anomalies.json

# Attempt a real LLM call for explanations (falls back to templates on any failure)
python anomaly_engine.py --use-llm
```

No dependencies beyond the Python standard library — nothing to install.

## Wiring up a real LLM (optional)

By default, explanations come from a template per rule type — fast, free,
and can't fail live. To use a real free-tier LLM instead, implement
`call_llm()` in `anomaly_engine.py` (a stub with example structure is
already there) and pass `--use-llm`. The template fallback stays in place
as a safety net if the API call fails or times out.

## Demo data disclosure

Sample data in `sample_data/` is self-generated mock data for development
and demo purposes — it is not live claim data and should be presented as
such.

## Definition of done

Running `anomaly_engine.py` on `fra_data.json` produces a valid
`anomalies.json` for every flagged claim, in the exact contract shape
above, with no crashes.
