"""
PS-7 FRA Monitoring — Member 4: Decision Support Dashboard
Reads analytics.json (KPIs, state table, charts) and anomalies.json
(anomaly panel + claim detail view). Does NOT detect anomalies and does NOT
build the map — those are Member 3's and Member 5's jobs.

Run:
    streamlit run app.py
"""

import json
import os
import subprocess
import sys

import pandas as pd
import plotly.express as px
import streamlit as st

# ---------------------------------------------------------------------------
# File locations — swapping in the real team files later is a one-line
# change: just overwrite these two JSON files (or point the paths below at
# Member 2's / Member 3's real output). No code restructuring needed.
# ---------------------------------------------------------------------------

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
ANALYTICS_PATH = os.path.join(DATA_DIR, "sample_data", "analytics.json")
ANOMALIES_PATH = os.path.join(DATA_DIR, "sample_data", "anomalies.json")

SEVERITY_COLOR = {"HIGH": "#e74c3c", "MEDIUM": "#f39c12", "LOW": "#f1c40f"}
SEVERITY_EMOJI = {"HIGH": "\U0001F534", "MEDIUM": "\U0001F7E0", "LOW": "\U0001F7E1"}
SEVERITY_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}


# ---------------------------------------------------------------------------
# Data loading — never crash the dashboard just because a file is missing.
# If a file isn't there yet, generate a small mock version on the fly so the
# UI still works stand-alone (this is what lets Member 4 build hour 0
# without waiting on Member 2 or Member 3).
# ---------------------------------------------------------------------------

@st.cache_data(show_spinner=False)
def load_json(path):
    with open(path) as f:
        return json.load(f)


def ensure_data_files():
    """If analytics.json / anomalies.json are missing, build mock versions."""
    os.makedirs(os.path.join(DATA_DIR, "sample_data"), exist_ok=True)

    if not os.path.exists(ANOMALIES_PATH):
        # Minimal hand-written mock in the agreed contract shape, used only
        # until Member 3's real anomalies.json lands.
        mock_anomalies = [
            {
                "claim_id": "FRA1023",
                "state": "Madhya Pradesh",
                "district": "Seoni",
                "severity": "HIGH",
                "risk_score": 87,
                "type": "LAND_RECORD_MISMATCH",
                "explanation": "The claimed land area is substantially higher than the recorded land area. This claim may require manual verification.",
                "recommendation": "Manual verification recommended.",
            },
            {
                "claim_id": "FRA1041",
                "state": "Madhya Pradesh",
                "district": "Mandla",
                "severity": "MEDIUM",
                "risk_score": 55,
                "type": "DELAYED_CLAIM",
                "explanation": "This claim has been pending significantly longer than the standard processing window.",
                "recommendation": "Escalate for administrative review.",
            },
            {
                "claim_id": "FRA1058",
                "state": "Madhya Pradesh",
                "district": "Betul",
                "severity": "LOW",
                "risk_score": 35,
                "type": "DATE_INCONSISTENCY",
                "explanation": "The recorded approval date precedes the claim date.",
                "recommendation": "Data entry correction recommended.",
            },
        ]
        with open(ANOMALIES_PATH, "w") as f:
            json.dump(mock_anomalies, f, indent=2)

    if not os.path.exists(ANALYTICS_PATH):
        # Build analytics.json via build_analytics.py so it's consistent
        # with whatever fra_data.json / anomalies.json exist right now.
        script = os.path.join(DATA_DIR, "build_analytics.py")
        subprocess.run(
            [sys.executable, script, "--mock", "30",
             "--anomalies", ANOMALIES_PATH, "--output", ANALYTICS_PATH],
            cwd=os.path.join(DATA_DIR, "sample_data"),
            capture_output=True,
        )
        # subprocess writes fra_data.json into sample_data/ too — that's fine,
        # it's the shared mock data file both modules can read.


# ---------------------------------------------------------------------------
# Page setup
# ---------------------------------------------------------------------------

st.set_page_config(page_title="FRA Monitoring — Decision Support", layout="wide")

ensure_data_files()
analytics = load_json(ANALYTICS_PATH)
anomalies = load_json(ANOMALIES_PATH)
anomalies_sorted = sorted(anomalies, key=lambda a: a["risk_score"], reverse=True)

st.title("Forest Rights Act — Decision Support Dashboard")
st.caption("Officer-facing monitoring panel — PS-7")

data_source = analytics.get("meta", {}).get("data_source", "unknown")
if data_source != "real":
    st.info(
        "This dashboard is currently running on **self-generated mock data** "
        "for development/demo purposes — not live claim data. Swap "
        "`sample_data/analytics.json` and `sample_data/anomalies.json` for "
        "the real team files to go live.",
        icon="\u2139\ufe0f",
    )

# ---------------------------------------------------------------------------
# 1. KPI cards
# ---------------------------------------------------------------------------

kpis = analytics["kpis"]
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Claims", f"{kpis['claims']:,}")
col2.metric("Approved", f"{kpis['approved']:,}")
col3.metric("Pending", f"{kpis['pending']:,}")
col4.metric("Anomalies", f"{kpis['anomalies']:,}")

st.divider()

# ---------------------------------------------------------------------------
# 2. State comparison table
# ---------------------------------------------------------------------------

st.subheader("State-wise Progress")
state_df = pd.DataFrame(analytics["state_summary"])
if not state_df.empty:
    state_df = state_df[["state", "claims", "approved", "pending", "rejected", "anomalies"]]
    state_df.columns = ["State", "Claims", "Approved", "Pending", "Rejected", "Anomalies"]
    st.dataframe(state_df, use_container_width=True, hide_index=True)
else:
    st.write("No state-level data available yet.")

# District breakdown, collapsed by default — the underlying data here only
# has one state, so the district table is where the real variation shows up.
with st.expander("District-level breakdown"):
    district_df = pd.DataFrame(analytics["district_summary"])
    if not district_df.empty:
        district_df = district_df[["state", "district", "claims", "approved", "pending", "rejected", "anomalies"]]
        district_df.columns = ["State", "District", "Claims", "Approved", "Pending", "Rejected", "Anomalies"]
        st.dataframe(district_df, use_container_width=True, hide_index=True)

st.divider()

# ---------------------------------------------------------------------------
# 3. Charts
# ---------------------------------------------------------------------------

st.subheader("Charts")
chart_col1, chart_col2 = st.columns(2)

with chart_col1:
    if not state_df.empty:
        rate_df = state_df.copy()
        rate_df["Approval Rate (%)"] = (rate_df["Approved"] / rate_df["Claims"] * 100).round(1)
        fig = px.bar(rate_df, x="State", y="Approval Rate (%)", title="Approval Rate by State",
                     color="Approval Rate (%)", color_continuous_scale="Greens")
        st.plotly_chart(fig, use_container_width=True)

with chart_col2:
    if not state_df.empty:
        fig = px.bar(state_df, x="State", y="Pending", title="Pending Claims by State",
                     color_discrete_sequence=["#f39c12"])
        st.plotly_chart(fig, use_container_width=True)

chart_col3, chart_col4 = st.columns(2)

with chart_col3:
    sev_counts = analytics.get("anomaly_by_severity", {})
    if sev_counts:
        sev_df = pd.DataFrame({"Severity": list(sev_counts.keys()), "Count": list(sev_counts.values())})
        fig = px.pie(sev_df, names="Severity", values="Count", title="Anomaly Distribution by Severity",
                     color="Severity", color_discrete_map=SEVERITY_COLOR)
        st.plotly_chart(fig, use_container_width=True)

with chart_col4:
    type_counts = analytics.get("anomaly_by_type", {})
    if type_counts:
        type_df = pd.DataFrame({"Type": list(type_counts.keys()), "Count": list(type_counts.values())})
        fig = px.bar(type_df, x="Type", y="Count", title="Anomaly Distribution by Type")
        st.plotly_chart(fig, use_container_width=True)

proc = analytics.get("processing_time", {})
if proc.get("avg_days") is not None:
    st.caption(
        f"Average processing time: **{proc['avg_days']} days** "
        f"(median {proc['median_days']} days, based on {proc['sample_size']} approved claims)."
    )

st.divider()

# ---------------------------------------------------------------------------
# 4 & 5. Anomaly panel + claim detail view
# ---------------------------------------------------------------------------

st.subheader("Anomaly Panel")

with st.sidebar:
    st.header("Filters")
    severity_filter = st.multiselect(
        "Severity", options=["HIGH", "MEDIUM", "LOW"], default=["HIGH", "MEDIUM", "LOW"]
    )
    search = st.text_input("Search claim ID or district")

filtered = [
    a for a in anomalies_sorted
    if a["severity"] in severity_filter
    and (search.lower() in a["claim_id"].lower() or search.lower() in a["district"].lower() if search else True)
]

if "selected_claim" not in st.session_state:
    st.session_state.selected_claim = None

if not filtered:
    st.write("No anomalies match the current filters.")
else:
    for a in filtered:
        emoji = SEVERITY_EMOJI.get(a["severity"], "\u26AA")
        label = a["type"].replace("_", " ").title()
        with st.container(border=True):
            left, right = st.columns([5, 1])
            with left:
                st.markdown(f"**{emoji} {a['severity']} — {label}**")
                st.caption(f"{a['district']}, {a['state']} — {a['claim_id']} · risk score {a['risk_score']}")
            with right:
                if st.button("View Details", key=f"view_{a['claim_id']}"):
                    st.session_state.selected_claim = a["claim_id"]

# Claim detail view — renders below the panel when a claim is selected
if st.session_state.selected_claim:
    selected = next((a for a in anomalies if a["claim_id"] == st.session_state.selected_claim), None)
    if selected:
        st.divider()
        st.subheader(f"Claim Detail — {selected['claim_id']}")
        d1, d2, d3 = st.columns(3)
        d1.metric("State", selected["state"])
        d2.metric("District", selected["district"])
        d3.metric("Risk Score", f"{selected['risk_score']} ({selected['severity']})")

        st.markdown("**AI Analysis**")
        st.write(selected["explanation"])
        st.markdown("**Recommendation**")
        st.write(selected["recommendation"])

        if st.button("Close detail view"):
            st.session_state.selected_claim = None
            st.rerun()
