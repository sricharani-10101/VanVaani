# FRA Decision Support Dashboard

**PS-7 — AI-powered Decision Support System for Forest Rights Act (FRA) Monitoring**
Member 4's module: the officer-facing monitoring panel.

This module does **not** detect anomalies and does **not** build the map —
it only reads files and displays them. It's built to run stand-alone,
against mock files, from hour zero.

## What it reads

- `sample_data/analytics.json` → KPI cards, state comparison table, district
  breakdown, charts
- `sample_data/anomalies.json` → anomaly panel + claim detail view
  (this is Member 3's exact output contract — field names must not change)

If either file is missing, the app generates a small mock version on first
run automatically (see `build_analytics.py`), so it never breaks a demo.

## Run it

```bash
pip install -r requirements.txt
streamlit run app.py
```

Opens in your browser automatically (usually `http://localhost:8501`).

## Rebuilding analytics.json

`analytics.json` is normally Member 2's job. Until that's ready (or if you
want to regenerate it from a new `fra_data.json` / `anomalies.json`), run:

```bash
cd sample_data
python ../build_analytics.py --input fra_data.json --anomalies anomalies.json --output analytics.json
```

Or generate fresh mock claim data from scratch:

```bash
python ../build_analytics.py --mock 30
```

`build_analytics.py` uses the **same district set** as Member 3's
`anomaly_engine.py`, so both modules stay consistent even when run
independently on their own mock data.

## Swapping in real team files

No code changes needed — just overwrite the two files:

- `sample_data/analytics.json` ← Member 2's real output
- `sample_data/anomalies.json` ← Member 3's real output (exact same
  contract shape shown below)

The dashboard shows a small banner whenever it's running on
self-generated/mock data, and hides it once `analytics.json`'s
`meta.data_source` field is `"real"` (set this when Member 2 hands off the
real file, or leave `build_analytics.py`'s default — it sets this
automatically when it's given a real `--input` file instead of `--mock`).

## `anomalies.json` contract (must match Member 3 exactly)

```json
[
  {
    "claim_id": "FRA1023",
    "state": "Madhya Pradesh",
    "district": "Seoni",
    "severity": "HIGH",
    "risk_score": 87,
    "type": "LAND_RECORD_MISMATCH",
    "explanation": "The claimed land area is substantially higher than the recorded land area. This claim may require manual verification.",
    "recommendation": "Manual verification recommended."
  }
]
```

## `analytics.json` contract (this module's own output)

```json
{
  "meta": {"generated_at": "...", "data_source": "mock|real", "total_claim_rows": 30},
  "kpis": {"claims": 30, "approved": 13, "pending": 10, "rejected": 7, "anomalies": 13},
  "state_summary": [
    {"state": "Madhya Pradesh", "claims": 30, "approved": 13, "pending": 10, "rejected": 7, "anomalies": 13}
  ],
  "district_summary": [
    {"state": "Madhya Pradesh", "district": "Seoni", "claims": 4, "approved": 2, "pending": 2, "rejected": 0, "anomalies": 2}
  ],
  "processing_time": {"avg_days": 42.1, "median_days": 30.0, "sample_size": 13},
  "monthly_claims": [{"month": "2025-08", "claims": 5}],
  "anomaly_by_severity": {"HIGH": 4, "MEDIUM": 5, "LOW": 4},
  "anomaly_by_type": {"LAND_RECORD_MISMATCH": 6, "DELAYED_CLAIM": 4, "DATE_INCONSISTENCY": 3}
}
```

If Member 2's real `analytics.json` uses different field names, either ask
them to match this shape, or adjust the small number of `analytics["..."]`
lookups near the top of `app.py` — everything else in the file is
presentation logic and won't need to change.

## Demo data disclosure

Sample data in `sample_data/` is self-generated mock data for development
and demo purposes — it is not live claim data and should be presented as
such (the dashboard's own banner does this automatically for you).

## Definition of done

`streamlit run app.py` shows working KPI cards, a state comparison table,
four charts, an anomaly panel, and a claim detail view — fully functional
against mock files. Swapping in the real `analytics.json` and
`anomalies.json` is copy-paste, no code restructuring.
