"""
PS-7 FRA Monitoring — Member 4: Analytics Builder
Consumes fra_data.json (+ anomalies.json if present) -> produces analytics.json

This is Member 4's OWN mock/build step, used only until Member 2's real
analytics.json is ready. It reads the exact same fra_data.json schema that
Member 3's anomaly_engine.py uses, so both modules stay in sync off one
shared data file.

Usage:
    python build_analytics.py                    # uses fra_data.json / anomalies.json if present, else mocks both
    python build_analytics.py --mock 30           # force-generate 30 mock claim rows and build analytics from them
    python build_analytics.py --input fra_data.json --anomalies anomalies.json --output analytics.json

No UI. No browser needed. Pure CLI, standard library only.
"""

import json
import random
import argparse
import os
import statistics
from datetime import datetime, timedelta
from collections import defaultdict

# ---------------------------------------------------------------------------
# CONFIG — must match Member 3's district set so the two modules agree
# ---------------------------------------------------------------------------

DISTRICT_GROUPS = {
    "Central & Eastern Forest Belt": ["Mandla", "Dindori", "Balaghat", "Seoni", "Chhindwara"],
    "Shahdol Region": ["Shahdol", "Umaria", "Anuppur"],
    "Western Tribal Belt": ["Alirajpur", "Jhabua", "Barwani"],
    "Southern / Forest-Connected": ["Betul", "Sidhi", "Singrauli", "Panna"],
}
STATES_DISTRICTS = {
    "Madhya Pradesh": [d for districts in DISTRICT_GROUPS.values() for d in districts]
}


# ---------------------------------------------------------------------------
# MOCK DATA GENERATOR — only used as a fallback if no fra_data.json is found.
# Same generator logic as Member 3's, kept here so this module can stand on
# its own for demo/dev without waiting on anyone.
# ---------------------------------------------------------------------------

def generate_mock_claims(n=30, seed=42):
    random.seed(seed)
    rows = []
    today = datetime(2026, 9, 4)

    for i in range(1, n + 1):
        state = random.choice(list(STATES_DISTRICTS.keys()))
        district = random.choice(STATES_DISTRICTS[state])

        claim_date = today - timedelta(days=random.randint(10, 400))
        status = random.choices(["PENDING", "APPROVED", "REJECTED"], weights=[0.3, 0.55, 0.15])[0]

        if status == "PENDING":
            approval_date = None
        else:
            if random.random() < 0.08:
                approval_date = claim_date - timedelta(days=random.randint(1, 20))
            else:
                approval_date = claim_date + timedelta(days=random.randint(5, 200))

        land_area = round(random.uniform(1.0, 10.0), 2)
        if random.random() < 0.15:
            land_record_area = round(land_area * random.uniform(0.4, 0.7), 2)
        else:
            land_record_area = round(land_area * random.uniform(0.92, 1.08), 2)

        rows.append({
            "claim_id": f"FRA{1000 + i}",
            "state": state,
            "district": district,
            "claim_date": claim_date.strftime("%Y-%m-%d"),
            "approval_date": approval_date.strftime("%Y-%m-%d") if approval_date else None,
            "status": status,
            "land_area": land_area,
            "land_record_area": land_record_area,
        })

    return rows


# ---------------------------------------------------------------------------
# ANALYTICS BUILD
# ---------------------------------------------------------------------------

def _empty_bucket():
    return {"claims": 0, "approved": 0, "pending": 0, "rejected": 0, "anomalies": 0}


def build_analytics(rows, anomalies, data_source="mock"):
    kpis = _empty_bucket()
    state_buckets = defaultdict(_empty_bucket)
    district_buckets = defaultdict(_empty_bucket)
    processing_days = []
    monthly_claims = defaultdict(int)

    anomaly_count_by_state = defaultdict(int)
    anomaly_count_by_district = defaultdict(int)
    anomaly_by_severity = defaultdict(int)
    anomaly_by_type = defaultdict(int)

    for a in anomalies:
        anomaly_count_by_state[a["state"]] += 1
        anomaly_count_by_district[(a["state"], a["district"])] += 1
        anomaly_by_severity[a["severity"]] += 1
        anomaly_by_type[a["type"]] += 1

    for row in rows:
        state = row["state"]
        district = row["district"]
        status = row["status"]

        for bucket in (kpis, state_buckets[state], district_buckets[(state, district)]):
            bucket["claims"] += 1
            if status == "APPROVED":
                bucket["approved"] += 1
            elif status == "PENDING":
                bucket["pending"] += 1
            elif status == "REJECTED":
                bucket["rejected"] += 1

        month_key = row["claim_date"][:7]  # "YYYY-MM"
        monthly_claims[month_key] += 1

        if status == "APPROVED" and row.get("approval_date"):
            c = datetime.strptime(row["claim_date"], "%Y-%m-%d")
            ap = datetime.strptime(row["approval_date"], "%Y-%m-%d")
            days = (ap - c).days
            if days >= 0:
                processing_days.append(days)

    kpis["anomalies"] = len(anomalies)

    state_summary = []
    for state, bucket in state_buckets.items():
        entry = dict(bucket)
        entry["state"] = state
        entry["anomalies"] = anomaly_count_by_state.get(state, 0)
        state_summary.append(entry)
    state_summary.sort(key=lambda s: s["claims"], reverse=True)

    district_summary = []
    for (state, district), bucket in district_buckets.items():
        entry = dict(bucket)
        entry["state"] = state
        entry["district"] = district
        entry["anomalies"] = anomaly_count_by_district.get((state, district), 0)
        district_summary.append(entry)
    district_summary.sort(key=lambda d: d["claims"], reverse=True)

    processing_time = {
        "avg_days": round(statistics.mean(processing_days), 1) if processing_days else None,
        "median_days": round(statistics.median(processing_days), 1) if processing_days else None,
        "sample_size": len(processing_days),
    }

    analytics = {
        "meta": {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "data_source": data_source,  # "mock" or "real" — dashboard shows this in a banner
            "total_claim_rows": len(rows),
        },
        "kpis": kpis,
        "state_summary": state_summary,
        "district_summary": district_summary,
        "processing_time": processing_time,
        "monthly_claims": [{"month": m, "claims": c} for m, c in sorted(monthly_claims.items())],
        "anomaly_by_severity": dict(anomaly_by_severity),
        "anomaly_by_type": dict(anomaly_by_type),
    }
    return analytics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="fra_data.json", help="path to claim data")
    parser.add_argument("--anomalies", default="anomalies.json", help="path to anomalies data (optional)")
    parser.add_argument("--output", default="analytics.json", help="path to write output")
    parser.add_argument("--mock", type=int, default=0, help="generate N mock claim rows instead of reading --input")
    args = parser.parse_args()

    data_source = "real"

    if args.mock:
        rows = generate_mock_claims(n=args.mock)
        with open("fra_data.json", "w") as f:
            json.dump(rows, f, indent=2)
        print(f"Generated {len(rows)} mock claim rows -> fra_data.json")
        data_source = "mock"
    elif os.path.exists(args.input):
        with open(args.input) as f:
            rows = json.load(f)
        print(f"Loaded {len(rows)} rows from {args.input}")
    else:
        print(f"No {args.input} found — generating 30 mock rows instead.")
        rows = generate_mock_claims(n=30)
        with open("fra_data.json", "w") as f:
            json.dump(rows, f, indent=2)
        data_source = "mock"

    if os.path.exists(args.anomalies):
        with open(args.anomalies) as f:
            anomalies = json.load(f)
        print(f"Loaded {len(anomalies)} anomalies from {args.anomalies}")
    else:
        print(f"No {args.anomalies} found — analytics will show 0 anomalies until Member 3's file is added.")
        anomalies = []
        data_source = "mock" if data_source == "mock" else "partial (no anomalies file)"

    analytics = build_analytics(rows, anomalies, data_source=data_source)

    with open(args.output, "w") as f:
        json.dump(analytics, f, indent=2)

    print(f"\nanalytics.json written -> {args.output}")
    print(f"  total claims: {analytics['kpis']['claims']}, "
          f"approved: {analytics['kpis']['approved']}, "
          f"pending: {analytics['kpis']['pending']}, "
          f"anomalies: {analytics['kpis']['anomalies']}")


if __name__ == "__main__":
    main()
